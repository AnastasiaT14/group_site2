<?php
$boxes = [
        [
            'img' => get_template_directory_uri() . '/assets/images/calendar.svg',
            'h2' => '15+',
            'h3' => 'Years of Experience',
         ],
         [
            'img' => get_template_directory_uri() . '/assets/images/ins.svg',
            'h2' => '15k+',
            'h3' => 'Happy Travellers',
         ],
         [
            'img' => get_template_directory_uri() . '/assets/images/loc.svg',
            'h2' => '650+',
            'h3' => 'Places Visited',
         ],
         [
            'img' => get_template_directory_uri() . '/assets/images/timer.svg',
            'h2' => '2k+',
            'h3' => 'Travel History',
         ],

];