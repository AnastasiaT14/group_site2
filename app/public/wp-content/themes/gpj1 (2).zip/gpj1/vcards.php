<?php
$vcards = [
    [
        'img' => get_template_directory_uri() . '/assets/images/v1.png',
        'h2' => 'Thailand',
        'h3-1' => '20+ Spots',
        'h3-2' => '2D & 3N',
    ],
     [
        'img' => get_template_directory_uri() . '/assets/images/v2.png',
        'h2' => 'Indonesia',
        'h3-1' => '20+ Spots',
        'h3-2' => '2D & 3N',
    ],
     [
        'img' => get_template_directory_uri() . '/assets/images/v3.png',
        'h2' => 'New Zeland',
        'h3-1' => '20+ Spots',
        'h3-2' => '2D & 3N',
    ],

];