<?php 
 $first_section = get_field('first_section');
 $hero_background = $first_section['hero_background'];
 $hero_title = $first_section['hero_title'];
 $hero_description = $first_section['hero_description']; 
 $button = $first_section['button'];

$second_section = get_field('second_section');
echo $second_section;

$third_section = get_field('third_section');

echo '<pre>';
var_dump($second_section); 
echo '</pre>';

get_header();
require 'cards.php';
require 'boxes.php';
require 'vcards.php';
?>

<main>
    <section class="section1">
        <?php if ($hero_background): ?>
        <img src="<?php echo $hero_background['url'] ?>" alt="<?php echo $hero_background['alt'] ?>">
        <?php endif; ?>
        <div class="hero-content">
            <h1><?php echo $hero_title ?></h1>
            <p><?php echo $hero_description ?></p>
            <button class="button">
                <a href="<?php echo $button ?>">Discover more</a>
            </button>
        </div>

   <section class="section2">
    <h1>Our Service</h1>
    <div class="cards">
        <?php
        foreach ($cards as $card) {
            echo '<div class="card">
                    <img src="' . $card['img'] . '" alt="">
                    <h2>' . $card['h2'] . '</h2>
                    <p>' . $card['p'] . '</p>
                  </div>';
        }
        ?>
    </div>
</section>
  <section class="section3">
    <img src="<?php echo get_template_directory_uri() . '/assets/images/map2.png'?>" alt="">
    <div class="content">
        <h1>We always try to give you the best service</h1>
        <p>We always try to make our customer Happy. We provide all kind offacilities. Your Satisfaction is our main priority.</p>
                <div class="boxes">
                    <?php
                    foreach($boxes as $box){
                        echo ' <div class="box">
                    <img src="'.$box['img'].'" alt="">
                        <h2>'.$box['h2'].'</h2>
                        <h3>'.$box['h3'].'</h3>
                    </div>';
                    }
                    ?>
                </div>
        </div>
  </section>
  <section class="section4">
         <div class="image-cont">
        <img src="<?php echo get_template_directory_uri() . '/assets/images/map.png'?>" alt="">
    </div>
    <div class="vcards">
        <?php
        foreach($vcards as $vcard){
                echo '<div class="vcard">
                <img src="'.$vcard['img'].'" alt="">
                <h2>'.$vcard['h2'].'</h2>
                <div class="inside-cont">
                <h3>'.$vcard['h3-1'].'</h3>
                <h3>'.$vcard['h3-2'].'</h3>
            </div>';
            }
        ?>
            
        </div>

    </div>
<div>
            <img src="<?php echo get_template_directory_uri() . '/assets/images/hh.png'?>" alt="">

</div>
    
   
  </section>
  
  
</main>

<!-- <?php
get_footer();
?> -->