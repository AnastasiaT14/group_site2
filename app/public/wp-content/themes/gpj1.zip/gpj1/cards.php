 <?php
 $cards = [
            [
                'img' => get_template_directory_uri() . '/assets/images/vector.svg',
                'h2' => 'Ticket Booking',
                'p' => 'We book all kinds of national or international tickets for your destination.',
            ],
            [
                'img' => get_template_directory_uri() . '/assets/images/house.svg',
                'h2' => 'Hotel Booking',
                'p' => 'You can easily book your budget hotel through our website.',
            ],
            [
                'img' => get_template_directory_uri() . '/assets/images/paper.svg',
                'h2' => 'Tour Plan',
                'p' => 'We provide you the best plans to explore more in a short time.',
            ],
        ];