<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the submitted email
    $email = $_POST["email"];

    // Validate or process the email as needed

    // Redirect to the thank-you page
    header("Location: /http://group-site.local/wp-admin/post.php?post=77&action=edit");
    exit();
}
?>
