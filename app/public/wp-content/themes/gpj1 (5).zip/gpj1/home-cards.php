<?php

$blocks = [
    [
        'img' => get_template_directory_uri() . '/assets/images/section-5-1.png',
        'description' => 'Explore the Beauty of the island for 3 days and 2 nights with our travel agency',
        'price' => '$500 / Person',
        'location' => 'Indonesia',
        'img2' => get_template_directory_uri() . '/assets/images/location.png',
    ],

    [
        'img' => get_template_directory_uri() . '/assets/images/section-5-2.png',
        'description' => 'Enjoy the Shrines and blossoms here in this beautiful country',
        'price' => '$800 / Person',
        'location' => 'Japan',
        'img2' => get_template_directory_uri() . '/assets/images/location.png',
    ],

    [
        'img' => get_template_directory_uri() . '/assets/images/section-5-3.png',
        'description' => 'Explore the majestic mountains and landscapes day and night',
        'price' => '$600 / Person',
        'location' => 'Mountains',
        'img2' => get_template_directory_uri() . '/assets/images/location.png',
    ],
];


    ?>
