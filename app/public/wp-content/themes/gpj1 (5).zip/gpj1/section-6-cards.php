
<?php

$books = [

 [
     'img' => get_template_directory_uri() . '/assets/images/section-6-1.png',
     'title' => 'Choose Destination'
 ],

 [
    'img' =>  get_template_directory_uri() . '/assets/images/section-6-2.png',
     'title' => 'Make Payment'
 ],

 [
    'img' =>  get_template_directory_uri() . '/assets/images/section-6-3.png',
     'title' => 'Reach Airport on Selected Date'
 ],

 ];

 ?>

