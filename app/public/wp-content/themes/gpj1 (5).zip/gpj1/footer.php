<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package gpj1
 */

?>
<footer id="colophon" class="site-footer gpj-footer">
		<div class="-container">
			<img src="<?php echo get_template_directory_uri() . '/assets/images/logo2.png'?>" alt="">
			<p class="paragraph2">
				Book your trip in minute, get fullControl for much longer.
			</p>
			</div>
			<div class="footer-texts">
				<h3>Company</h3>
				<p class="paragraph">About</p>
				<p class="paragraph">Careers</p>
				<p class="paragraph">Mobile</p>
			</div>
			<div class="footer-texts">
				<h3>Contact</h3>
				<p class="paragraph">About</p>
				<p class="paragraph">Careers</p>
				<p class="paragraph">Mobile</p>
			</div>
			<div class="footer-texts">
				<h3>Contact</h3>
				<p class="paragraph">About</p>
				<p class="paragraph">Careers</p>
				<p class="paragraph">Mobile</p>
			</div>

			<div class="third-sec">
				<div class="footer-socials">
					<img src="<?php echo get_template_directory_uri() . '/assets/images/fb.png'?>" alt="">	
					<img src="<?php echo get_template_directory_uri() . '/assets/images/insta.png'?>" alt="">
					<img src="<?php echo get_template_directory_uri() . '/assets/images/twitter.png'?>" alt="">
			
				
			<div class="socials-container">
				<p> 
					Discover our app
				</p>

			</div>
			<div class="mini-socials-container">
					<img src="<?php echo get_template_directory_uri() . '/assets/images/play_s.png'?>" alt="">
					<img src="<?php echo get_template_directory_uri() . '/assets/images/apple_s.png'?>" alt="">
				</div>
			</div>
			
		
		
	</footer><!-- #colophon -->
</div><!-- #page -->
<<?php wp_footer(); ?>

<script>
  document.addEventListener("DOMContentLoaded", function() {
    let lastScrollTop = 0;

    window.addEventListener("scroll", function() {
      let st = window.pageYOffset || document.documentElement.scrollTop;
      let windowHeight = window.innerHeight;
      let bodyHeight = document.body.clientHeight;

      if (st + windowHeight >= bodyHeight) {
        // User is at the end of the page
        document.body.classList.remove("hide-footer");
      } else {
        // User is not at the end of the page
        document.body.classList.add("hide-footer");
      }

      lastScrollTop = st;
    });

    // Initially hide the footer
    document.body.classList.add("hide-footer");
  });
</script>

</body>
</html>
