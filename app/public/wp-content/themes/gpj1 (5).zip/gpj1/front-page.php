<!-- Front-Page.php -->
<?php 

get_header();
require 'cards.php';
require 'boxes.php';
require 'vcards.php';
require 'home-cards.php';
require 'section-6-cards.php';
?>

<main>
 <section class="section1">
       
        <img src="<?php echo get_template_directory_uri() . '/assets/images/background3.png'?>" alt="">
      
        <div class="hero-content">
            <h1>Your Imagination Is Your Only Limit</h1>
            <p>We always try to make our customer Happy. We provide all kind of facilities. Your Satisfaction is our main priority</p>
            <button class="button">
                <a href="">Discover more</a>
            </button>
        </div> 

   <section class="section2">
    <h1>Our Service</h1>
    <div class="cards">
        <?php
        foreach ($cards as $card) {
            echo '<div class="card">
                    <img src="' . $card['img'] . '" alt="">
                    <h2>' . $card['h2'] . '</h2>
                    <p>' . $card['p'] . '</p>
                  </div>';
        }
        ?>
    </div>
</section>
  <section class="section3">
    <img src="<?php echo get_template_directory_uri() . '/assets/images/map2.png'?>" alt="">
    <div class="content">
        <h1>We always try to give you the best service</h1>
        <p>We always try to make our customer Happy. We provide all kind offacilities. Your Satisfaction is our main priority.</p>
                <div class="boxes">
                    <?php
                    foreach($boxes as $box){
                        echo ' <div class="box">
                    <img src="'.$box['img'].'" alt="">
                        <h2>'.$box['h2'].'</h2>
                        <h3>'.$box['h3'].'</h3>
                    </div>';
                    }
                    ?>
                </div>
        </div>
  </section>
  <section class="outer4-section">
        <h1>Our Popular Distinations</h1>
  </section>
 <section class="section4">
    <div class="image-cont">
        <img src="<?php echo get_template_directory_uri() . '/assets/images/map1.png'?>" alt="">
    </div>
    <div class="vcards">
        <?php
        foreach ($vcards as $vcard) {
            echo '<div class="vcard">
                    <img src="' . $vcard['img'] . '" alt="">
                    <div class="text-content">
                        <h2>' . $vcard['h2'] . '</h2>
                        <div class="mini-text-content">
                            <h3>' . $vcard['h3-1'] . '</h3>
                            <h3>' . $vcard['h3-2'] . '</h3>
                        </div>
                    </div>
                  </div>';
        }
        ?>
    </div>
</section>
 <section class="home-section-5">
        <div class="row">
            <h1 class="hero-title">Best Packages For You</h1>
            <div class="links">
                    <a href="" class="btm color">Hot Deals</a>
                    <a href="" class="btm">Backpack</a>
                    <a href="" class="btm">South Asia</a>
                    <a href="" class="btm">Honeymoon</a>
                    <a href="" class="btm">Europe</a>
                    <a href="" class="btm">More</a>
             </div>
             <div class="section-5-content">
                <?php
                    foreach ($blocks as $block) {
                        echo '<div class="section-5-content-card">
                        <img class="location" src="' . $block['img']. '" alt="">
                        <div class="card-text-1">
                            <p>3 Days, 2 NIghts</p>
                            <p>' . $block['price']. '</p>
                        </div>
                        <p class="section-5-description">' . $block['description']. '</p>
                        <div class="card-text-2">
                            <div class="location-box">
                                <img  src="' . $block['img2']. '" alt="">
                                <p>' . $block['location']. '</p>
                            </div>
                            <p>Know More</p>
                        </div>
                    </div>';
                    }
                ?>
             </div> 
             <div class="main-buttom">
                 <a  href="">Discover More</a>
             </div> 
        </div>
    </section>
     <section class="home-section-6">
        <div class="row">
            <div class="section-6-titles">
                <h1 class="hero-title">Book Your Next Trip in 3 Easy Steps</h1>
                <h2 class="secondary-title">Easy and Fast</h2>
            </div>
            <div class="section-6-content">
                <div class="left-content">
                    <?php foreach($books as $book) {
                        echo '<div class="left-content-card">
                        <img src="' . $book['img']. '" alt="">
                        <div class="left-content-card-text">
                            <h3>' . $book['title']. '</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Urna, tortor tempus.</p>
                        </div>
                    </div>';
                    }
                    ?>
                </div>
                <div class="right-content-background">
                    <img src="<?php echo get_template_directory_uri() . '/assets/images/background.png'?>" alt="">
                    <div class="right-content">
                        <div class="right-content-card">
                            <img src="<?php echo get_template_directory_uri() . '/assets/images/section-6-right-1.png'?>" alt="">
                            <p class="right-section-first-p">Trip To Greece</p>
                            <div class="line">
                                <p>14-29 June |</p>
                                <p>by Robbin joseph</p>
                            </div>
                            <div class="icons">
                                <img src="<?php echo get_template_directory_uri() . '/assets/images/leaf.png'?>" alt="">
                                <img src="<?php echo get_template_directory_uri() . '/assets/images/map.png'?>" alt="">
                                <img src="send.png" alt="">
                            </div>
                            <div class="right-content-last">
                                <div class="right-content-last-content">
                                    <img src="<?php echo get_template_directory_uri() . '/assets/images/building.png'?>" alt="">
                                    <p>24 people going</p>
                                </div>
                                <img src="<?php echo get_template_directory_uri() . '/assets/images/heart.png'?>" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="add">
                    <div class="add-content">
                        <img src="<?php echo get_template_directory_uri() . '/assets/images/right-section-add.png'?>" alt="">
                        <div class="content-text">
                            <p class="first-p">Ongoing</p>
                            <p class="second-p">Trip to rome</p>
                        </div>
                    </div>
                    <div class="loading">
                        <p><span>40%</span>completed</p>
                        <img src="<?php echo get_template_directory_uri() . '/assets/images/loading.png'?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    

    <section class="home-section-7">
        <div class="row">
            <h1 class="home-7-title">
                What People Say About Us
            </h1>
            <div class="section-7-content">
                <img src="<?php echo get_template_directory_uri() . '/assets/images/section-7-1.png'?>" alt="">
            </div>
            <div class="section-7-main-content">
                <p class="section-7-first-p">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam, purus sit amet luctus venenatis, lectus magna fringilla urna, porttitor
                </p>
                <p class="section-7-second-p">
                    -Jeo Stanlee
                </p>
            </div>
            <div class="section-7-second-image">
                <img src="<?php echo get_template_directory_uri() . '/assets/images/section-7-2.png'?>" alt="">
            </div>
        </div>
    </section>


      <section class="section8">
    <div class="e-container">
        <div class="inside-e-container">
            <h2>Subscribe to get information, latest news and other interesting offers about Cobham</h2>
            <div class="form-cont">
                <form action="/thank-you-for-subscribing" method="post">
                    <input type="email" placeholder=" ✉ Your email" id="email" name="email" required class="first-input">
                    <input type="submit" value="Subscribe" class="button">
                </form>
            </div>
        </div>
    </div>
</section>

</main>

 <?php
get_footer();
?> 