<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'gpj1' ); ?></a>

	<header id="masthead" class="site-header">
		<div class="container">
			<div class="header-content">
				<div class="site-branding">
					<?php the_custom_logo(); ?>
				</div>

				<nav id="site-navigation" class="main-navigation gpj-navigation">
					<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'gpj1' ); ?></button>
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'menu-1',
							'menu_id'        => 'primary-menu',
							'menu_class'     => 'header-menu',
						)
					);
					?>
				</nav><!-- #site-navigation -->
				
				<div class="img">
					<img src="<?php echo get_template_directory_uri() . '/assets/images/star.svg'; ?>" alt="">
					<img src="<?php echo get_template_directory_uri() . '/assets/images/pf.svg'; ?>" alt="">
				</div>
			</div>
		</div>
	</header><!-- #masthead -->

	<script>
		document.addEventListener("DOMContentLoaded", function() {
			let header = document.getElementById("masthead");

			window.addEventListener("scroll", function() {
				let scrollPosition = window.scrollY;

				// Adjust the scroll threshold as needed
				if (scrollPosition > 100) {
					header.style.backgroundColor = '#00A651';
				} else {
					header.style.backgroundColor = 'transparent'; // Set your initial background color here
				}
			});
		});
	</script>

<?php wp_footer(); ?>
</body>
</html>
